import os
from pathlib import Path
from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    RegisterEventHandler,
)
from launch.event_handlers import OnProcessExit
from launch.substitutions import Command, LaunchConfiguration

from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue 
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import SetEnvironmentVariable

def generate_launch_description():
    #Link to package
    package_dir = get_package_share_directory("usv_description")
    gazebo_package_dir = get_package_share_directory("ros_gz_sim")
    #Link to model (use declare argument to allow flexible input argument)
    model_path = os.path.join(package_dir, "urdf", "usv.urdf.xacro")
    usv_model = DeclareLaunchArgument("usv_model", default_value=model_path,
                                      description="Absolute path to robot urdf file")
    #Declare world path
    world_path = os.path.join(
    package_dir,
    "urdf",
    "environment.sdf"
    )
    #Resource path (for gazebo to find meshes)
    gazebo_resource_path = SetEnvironmentVariable(
    name="GZ_SIM_RESOURCE_PATH",
    value=[
        str(Path(package_dir).parent.resolve())
    ]
    )
    #convert xacro to standard urdf xml
    usv_description = ParameterValue(Command(["xacro ", LaunchConfiguration("usv_model")]),
                                     value_type=str)
    #run state publisher executable (TF transform illustate)
    robot_state_publisher_node = Node(
                                      package="robot_state_publisher",
                                      executable="robot_state_publisher",
                                      parameters=[{"robot_description": usv_description,
                                                   "use_sim_time": True}
                                                  ]
                                      )
    #Initialize gazebo
    gazebo = IncludeLaunchDescription(
                                    PythonLaunchDescriptionSource(
                                        os.path.join(gazebo_package_dir, 
                                        'launch', 'gz_sim.launch.py')),
                                    launch_arguments={'gz_args': ["-r ", world_path]}.items()
                                    )
    #Spawn usv
    gz_spawn_robot = Node(
                        package="ros_gz_sim",
                        executable="create",
                        output="screen",
                        arguments=[
                            "-world", "industrial_sludge_pond",
                            "-topic", "robot_description",
                            "-name", "usv",
                            "-x", "-25.0",
                            "-y", "-40.0",
                            # Waterline is 0.474 m below the body origin.
                            "-z", "0.474",

                            "-R", "0.0",
                            "-P", "0.0",
                            "-Y", "0.0",
                        ],
                        )

    # Start controllers as soon as the USV has been inserted. This prevents the
    # heavy pump from falling along the prismatic joint before it is controlled.
    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=[
            "joint_state_broadcaster",
            "--controller-manager",
            "/controller_manager",
        ],
        output="screen",
    )

    pump_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=[
            "pump_controller",
            "--controller-manager",
            "/controller_manager",
        ],
        output="screen",
    )

    start_controllers_after_spawn = RegisterEventHandler(
        OnProcessExit(
            target_action=gz_spawn_robot,
            on_exit=[
                joint_state_broadcaster_spawner,
                pump_controller_spawner,
            ],
        )
    )
    # Brige time
    gz_ros2_bridge = Node(
                        package="ros_gz_bridge",
                        executable="parameter_bridge",
                        arguments=[
                            "/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock",
                        ]
                        )
    
    return LaunchDescription([
                            gazebo_resource_path,
                            usv_model,
                            robot_state_publisher_node,
                            gazebo,
                            gz_spawn_robot,
                            start_controllers_after_spawn,
                            gz_ros2_bridge
                            ])
